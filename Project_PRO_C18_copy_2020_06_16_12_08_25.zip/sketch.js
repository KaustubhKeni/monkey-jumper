//Global Variables
var monkey, monkeyrunning;
var ground; 
var stone,stonegroup,stoneimage;
var bananna,banannagroup,banannaimage;
var gameoverimage,gameover,restart,restartimage,bg, bgimage;
var score;
function preload(){
  score=0;
bgimage=loadImage("jungle.jpg");
gameoverimage=loadImage("gameOver.png");
 restartimage=loadImage("restart.png"); 
banannaimage=loadImage("Banana.png") ;
 stoneimage=loadImage("stone.png"); 
  monkeyrunning=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png" );
  
}


function setup() {
  createCanvas(600,300);

  
  
  
  bg=createSprite(300, 300, 700, 600)
bg.addImage("jungle",bgimage)

monkey=createSprite(30, 290, 20, 20);
monkey.addAnimation("run",monkeyrunning);
monkey.scale=0.1;

ground=createSprite(300, 300, 630, 10);
ground.visible=false;

stonegroup= new Group ()
fruitsgroup= new Group()

}


function draw(){
 background(180); 
monkey.collide(ground);

if(keyDown("space")){
monkey.velocityY=-15;
}
monkey.velocityY=monkey.velocityY+1;

bg.velocityX=-5;

  
  stroke=("yellow");
textSize(20);
fill("yellow");

  
  
  
if(ground.x<0){
ground.x=ground.width/2;
}

if(bg.x<0){
bg.x=bg.width/2;
}
if(fruitsgroup.isTouching(monkey)){
  fruitsgroup.destroyEach()
score=score+3;
}
  
  
  
if(stonegroup.isTouching(monkey)){
bg.velocityX=0;

  monkey.destroy();
stonegroup.destroyEach();
fruitsgroup.destroyEach();
gameover=createSprite(300, 150, 100, 100);
gameover.addImage("gameOver.png",gameoverimage);
restart=createSprite(300,200,30,30);
  restart.addImage("restart.png",restartimage)
restart.scale=0.5;
}sss








spawnStones();
spawnFruits();
drawSprites();
text("score"+score ,460 ,50);

}

function spawnStones (){
if(frameCount % 80 ===0){


stone=createSprite(600, 300, 10,10);
stone.addImage("stone.png",stoneimage)
stone.scale=0.3;
stone.velocityX=-5;
stone.lifetime=120;
stonegroup.add(stone);
}
}

function spawnFruits (){
if(frameCount % 40 ===0){


bananna=createSprite(600, 170, 0.1,0.1);
bananna.addImage("Banana.png",banannaimage)
bananna.scale=0.1;
bananna.velocityX=-5;
bananna.lifetime=120;
fruitsgroup.add(bananna);

}
}



